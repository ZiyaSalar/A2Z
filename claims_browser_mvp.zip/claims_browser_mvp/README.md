# Claims Assistant — browser MVP prototype

This is a local-only testing UI. **No authentication, authorization, persistent state, or production-ready confirmations.** Do not expose ports publicly or use real claim data.

## Files

- `backend/app/services/agent_service.py`: MCP client + GPT-4.1-mini orchestration; in-memory per-chat state
- `backend/app/api/chat.py`: FastAPI chat/confirmation/file-upload routes
- `frontend/streamlit_app.py`: Streamlit browser interface

## Integrate

1. From repository root, copy the above files into the matching locations. Preserve existing files (do not overwrite `backend/app/mcp/server.py`, `backend/app/main.py`, or existing RAG service).
2. Ensure `mcp/server.py` exports `mcp` with existing tools `get_claim_details`, `get_claim_manifest`, `get_required_documents`, `get_claim_summary`, `ask_claim_question`, `request_document_upload`, `create_claim`.
3. IMPORTANT: The `get_claim_summary`/`ask_claim_question` MCP tools must be `async def` and use `httpx.AsyncClient`, if they make HTTP requests to the same FastAPI process (see assistant instructions). Avoid synchronous HTTP callbacks to the same single-worker event loop.
4. Add `from backend.app.api.chat import router as chat_router` and `app.include_router(chat_router)` to `backend/app/main.py`.
5. Install `streamlit` if not installed. Run Uvicorn on localhost port 8000, and Streamlit on localhost port 8501; Codespaces ports should be private.
6. Test fictional claim creation, upload, summary and RAG Q&A.

## Limitations

Per-worker in-memory state is lost on reload; multiple workers break continuity. Session IDs aren't user authentication. For production add authentication/claim-level authorization, persistent conversation and pending action state, server-side identity-bound approvals and idempotency, and an outbox/retry strategy for indexing.
