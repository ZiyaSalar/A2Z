import { useEffect, useRef, useState } from 'react';
import { Activity, Bot, CheckCircle2, ChevronRight, CircleAlert, ClipboardList, FileText, FolderPlus, Layers3, MessageSquare, Paperclip, RefreshCw, Send, ShieldCheck, UploadCloud, X } from 'lucide-react';
import { api } from './api';

const CATEGORIES = [
  ['admission_advice', 'Admission advice'],
  ['discharge_summary', 'Discharge summary'],
  ['hospital_bill', 'Hospital bill'],
  ['signed_claim_form', 'Signed claim form'],
];
const fmt = value => value ? String(value).replaceAll('_', ' ') : '—';
const short = value => value ? `${String(value).slice(0, 8)}…` : '—';

function Status({ value }) {
  const status = (value || '').toLowerCase();
  const tone = ['received', 'completed', 'ready_for_review', 'synchronized'].includes(status) ? 'good' :
    ['needs_review', 'incomplete', 'pending'].includes(status) ? 'warn' : 'neutral';
  return <span className={`status ${tone}`}>{fmt(value)}</span>;
}

function Notice({ text, onClose }) {
  if (!text) return null;
  return <div className="notice" role="alert"><CircleAlert size={16}/><span>{text}</span><button className="icon-button" onClick={onClose} aria-label="Dismiss"><X size={16}/></button></div>;
}

function ChatPanel({ claims, onChange }) {
  const [sessionId, setSessionId] = useState(null);
  const [history, setHistory] = useState([]);
  const [pending, setPending] = useState(null);
  const [message, setMessage] = useState('');
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [history, pending]);

  function accept(data) {
    setSessionId(data.session_id);
    if (data.message) setHistory(h => [...h, { role: 'assistant', text: data.message }]);
    setPending(['confirm_claim', 'upload_request'].includes(data.type) ? data : null);
    if (data.claim_id || data.type === 'upload_complete') onChange();
  }

  async function send(event) {
    event.preventDefault();
    const value = message.trim();
    if (!value || busy || pending) return;
    setMessage(''); setError('');
    setHistory(h => [...h, { role: 'user', text: value }]);
    setBusy(true);
    try { accept(await api('/api/chat/message', { method: 'POST', body: { session_id: sessionId, message: value } })); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  async function confirm(approved) {
    if (!pending) return;
    setBusy(true); setError('');
    try { accept(await api('/api/chat/confirm', { method: 'POST', body: { session_id: sessionId, approved } })); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  async function upload() {
    if (!file || !pending) return;
    if (file.size > 10 * 1024 * 1024) { setError('Maximum file size is 10 MB.'); return; }
    setBusy(true); setError('');
    const form = new FormData(); form.append('file', file);
    try {
      const data = await api(`/api/chat/upload?session_id=${encodeURIComponent(sessionId)}`, { method: 'POST', form });
      accept(data);
      const result = data.result || {};
      setHistory(h => [...h, { role: 'assistant', text: `File: ${result.filename || file.name}\nClassification: ${fmt(result.classification?.predicted_type)}\nDocument status: ${fmt(result.document_status)}\nIndexing: ${fmt(result.rag_indexing?.status)}` }]);
      setFile(null);
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  async function cancelUpload() {
    setBusy(true); setError('');
    try { accept(await api('/api/chat/cancel-upload', { method: 'POST', body: { session_id: sessionId } })); setFile(null); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  function newChat() { setSessionId(null); setHistory([]); setPending(null); setError(''); setFile(null); }
  return <section className="chat-panel">
    <div className="panel-heading"><div className="heading-icon"><Bot size={20}/></div><div><h2>AI claim assistant</h2><p>MCP-backed chat · GPT-4.1-mini</p></div><button className="ghost" onClick={newChat} title="Start a new chat">New chat</button></div>
    <div className="messages">
      {history.length === 0 && <div className="empty-chat"><div className="empty-icon"><MessageSquare size={30}/></div><h3>How can I help?</h3><p>Create a claim, request a document upload, get a summary, or ask questions with citations.</p><button className="suggestion" onClick={() => setMessage('What documents are required for hospitalization?')}>What documents are required for hospitalization? <ChevronRight size={14}/></button></div>}
      {history.map((item, i) => <div className={`bubble ${item.role}`} key={i}><span className="bubble-role">{item.role === 'assistant' ? 'Assistant' : 'You'}</span><div>{item.text}</div></div>)}
      {pending?.type === 'confirm_claim' && <div className="action-panel"><div className="action-title"><ShieldCheck size={18}/> Confirm claim creation</div><div className="kv"><span>Claimant</span><strong>{pending.claim?.claimant_name}</strong><span>Policy</span><strong>{pending.claim?.policy_number}</strong><span>Type</span><strong>{pending.claim?.claim_type}</strong></div><div className="action-buttons"><button className="primary" disabled={busy} onClick={() => confirm(true)}>Confirm & create</button><button className="secondary" disabled={busy} onClick={() => confirm(false)}>Cancel</button></div></div>}
      {pending?.type === 'upload_request' && <div className="action-panel"><div className="action-title"><Paperclip size={18}/> Attach a document</div><p>Claim: <code>{pending.claim_id}</code></p><p>Type: <strong>{fmt(pending.document_type)}</strong></p><input type="file" accept=".txt,.pdf,.png,.jpg,.jpeg" onChange={e => setFile(e.target.files?.[0] || null)}/><div className="action-buttons"><button className="primary" disabled={!file || busy} onClick={upload}><UploadCloud size={16}/> Upload file</button><button className="secondary" disabled={busy} onClick={cancelUpload}>Cancel</button></div></div>}
      {busy && <div className="typing"><span className="spinner"/> Processing request…</div>}
      <div ref={end}/>
    </div>
    <Notice text={error} onClose={() => setError('')}/>
    <form className="chat-composer" onSubmit={send}><input value={message} disabled={busy || !!pending} onChange={e => setMessage(e.target.value)} placeholder={pending ? 'Complete the pending action first…' : 'Message the claims assistant…'} aria-label="Chat message"/><button className="send-button" disabled={!message.trim() || busy || !!pending} type="submit" aria-label="Send message"><Send size={18}/></button></form>
    <p className="chat-footnote">Prototype · use fictional claim data only · human review required</p>
  </section>;
}

export default function App() {
  const [tab, setTab] = useState('workspace');
  const [claims, setClaims] = useState([]);
  const [selected, setSelected] = useState('');
  const [documents, setDocuments] = useState([]);
  const [verification, setVerification] = useState(null);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ claimant_name: '', policy_number: '', claim_type: 'hospitalization' });
  const [documentType, setDocumentType] = useState('hospital_bill');
  const [documentFile, setDocumentFile] = useState(null);
  const [uploadKey, setUploadKey] = useState(0);
  const active = claims.find(c => c.claim_id === selected);

  async function loadClaims(chooseId) {
    setLoading(true);
    try {
      const data = await api('/api/claims/');
      setClaims(Array.isArray(data) ? data : []);
      setSelected(prev => chooseId || (data.some(c => c.claim_id === prev) ? prev : data[0]?.claim_id || ''));
    } catch (e) { setNotice(e.message); }
    finally { setLoading(false); }
  }

  useEffect(() => { loadClaims(); }, []);
  useEffect(() => {
    let live = true;
    setDocuments([]); setVerification(null);
    if (!selected) return;
    Promise.all([api(`/api/claims/${encodeURIComponent(selected)}/documents`), api(`/api/claims/${encodeURIComponent(selected)}/verification`)]).then(([d, v]) => {
      if (live) { setDocuments(Array.isArray(d) ? d : []); setVerification(v); }
    }).catch(e => { if (live) setNotice(e.message); });
    return () => { live = false; };
  }, [selected, claims]);

  async function create(event) {
    event.preventDefault(); setBusy(true); setNotice('');
    try {
      const data = await api('/api/claims/', { method: 'POST', body: form });
      setForm({ claimant_name: '', policy_number: '', claim_type: 'hospitalization' });
      await loadClaims(data.claim_id);
    } catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }

  async function uploadDocument(event) {
    event.preventDefault(); if (!selected || !documentFile) return;
    if (documentFile.size > 10 * 1024 * 1024) { setNotice('Maximum file size is 10 MB.'); return; }
    const payload = new FormData(); payload.append('file', documentFile); payload.append('document_type', documentType);
    setBusy(true); setNotice('');
    try {
      const data = await api(`/api/claims/${encodeURIComponent(selected)}/documents`, { method: 'POST', form: payload });
      setNotice(`Uploaded ${data.filename || documentFile.name}. Indexing: ${data.rag_indexing?.status || 'check response'}.`);
      setDocumentFile(null); setUploadKey(k => k + 1);
      await loadClaims(selected);
    } catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark"><Layers3 size={22}/></div><div><strong>Claims<span>AI</span></strong><small>DOCUMENT ASSISTANT</small></div></div><div className="nav-title">WORKSPACE</div><button className={`nav-link ${tab === 'workspace' ? 'active' : ''}`} onClick={() => setTab('workspace')}><ClipboardList size={18}/> Claims workspace</button><button className={`nav-link ${tab === 'assistant' ? 'active' : ''}`} onClick={() => setTab('assistant')}><Bot size={18}/> AI assistant</button><div className="sidebar-bottom"><ShieldCheck size={16}/><span>Human-in-the-loop review</span></div></aside>
    <div className="main-area"><header className="topbar"><div className="breadcrumb">Claims workspace <ChevronRight size={13}/> <strong>{tab === 'workspace' ? 'Overview' : 'AI Assistant'}</strong></div><div className="env"><span className="live-dot"/> LOCAL PROTOTYPE</div></header>
    <main className="content"><div className="page-heading"><div><p className="eyebrow">CLAIMS MANAGEMENT PLATFORM</p><h1>{tab === 'workspace' ? 'Claims overview' : 'AI assistant'}</h1><p>{tab === 'workspace' ? 'Manage claims, review documents, and track verification.' : 'Ask about claims or initiate actions through MCP tools.'}</p></div><button className="secondary refresh" onClick={() => loadClaims(selected)}><RefreshCw size={15}/> Refresh</button></div><Notice text={notice} onClose={() => setNotice('')}/>
    {tab === 'workspace' ? <>
      <div className="metrics"><div className="metric"><div><p>Total claims</p><strong>{claims.length}</strong></div><FolderPlus size={24}/></div><div className="metric"><div><p>Selected claim docs</p><strong>{documents.length}</strong></div><FileText size={24}/></div><div className="metric"><div><p>Requirements satisfied</p><strong>{verification ? `${verification.received_count}/${verification.required_count}` : '—'}</strong></div><CheckCircle2 size={24}/></div></div>
      <div className="workspace-grid"><section className="surface"><div className="section-header"><div><h2>Claims</h2><p>Choose a claim to inspect</p></div>{loading && <RefreshCw size={16} className="spin"/>}</div><div className="claim-list">{claims.length === 0 ? <p className="muted-pad">No claims yet. Create one below.</p> : claims.map(c => <button key={c.claim_id} className={`claim-item ${c.claim_id === selected ? 'selected' : ''}`} onClick={() => setSelected(c.claim_id)}><div className="claim-symbol"><FileText size={17}/></div><div><strong>{c.claimant_name}</strong><small>{short(c.claim_id)} · {c.policy_number}</small></div><ChevronRight size={16}/></button>)}</div><div className="section-header"><div><h2>Create a claim</h2><p>Manual entry</p></div></div><form className="field-form" onSubmit={create}><label>Claimant name<input required value={form.claimant_name} onChange={e => setForm(f => ({...f, claimant_name:e.target.value}))}/></label><label>Policy number<input required value={form.policy_number} onChange={e => setForm(f => ({...f, policy_number:e.target.value}))}/></label><label>Claim type<input required value={form.claim_type} onChange={e => setForm(f => ({...f, claim_type:e.target.value}))}/></label><button className="primary" disabled={busy} type="submit"><FolderPlus size={16}/> Create claim</button></form></section>
      <section className="surface details"><div className="section-header"><div><h2>Claim details</h2><p>{active ? active.claim_id : 'Select a claim to view its details'}</p></div>{active && <Status value={active.verification_status}/>}</div>{active ? <><div className="detail-summary"><div><span>Claimant</span><strong>{active.claimant_name}</strong></div><div><span>Policy</span><strong>{active.policy_number}</strong></div><div><span>Claim type</span><strong>{fmt(active.claim_type)}</strong></div><div><span>Status</span><Status value={active.status}/></div></div><div className="section-header subhead"><div><h2>Verification checklist</h2><p>Requirements not satisfied remain missing</p></div></div><div className="checklist">{CATEGORIES.map(([key, label]) => {const missing = verification?.missing_documents?.includes(key); const status = verification ? (missing ? 'missing' : 'received') : 'loading'; return <div className="check-row" key={key}><div className={`check-icon ${!missing && verification ? 'complete' : ''}`}>{!missing && verification ? <CheckCircle2 size={16}/> : <CircleAlert size={16}/>}</div><span>{label}</span><Status value={status}/></div>;})}</div><div className="section-header subhead"><div><h2>Uploaded documents</h2><p>{documents.length} file(s) attached to this claim</p></div></div><div className="document-list">{documents.length === 0 ? <p className="muted-pad">No documents uploaded yet.</p> : documents.map(doc => <div className="document-row" key={doc.document_id}><div className="doc-icon"><FileText size={17}/></div><div className="doc-info"><strong>{doc.filename}</strong><small>{fmt(doc.document_type)}</small></div><Status value={doc.document_status}/></div>)}</div><div className="section-header subhead"><div><h2>Upload a document</h2><p>OCR, classification and hybrid indexing run automatically</p></div></div><form className="field-form upload-form" onSubmit={uploadDocument}><label>Document type<select value={documentType} onChange={e=>setDocumentType(e.target.value)}>{CATEGORIES.map(([key,label]) => <option value={key} key={key}>{label}</option>)}</select></label><label>Choose file<input key={uploadKey} required type="file" accept=".pdf,.png,.jpg,.jpeg,.txt" onChange={e => setDocumentFile(e.target.files?.[0] || null)}/></label><button className="primary" disabled={busy || !documentFile}><UploadCloud size={16}/> Upload and process</button></form></> : <p className="muted-pad">Choose an existing claim, or create a new one.</p>}</section></div>
    </> : <ChatPanel claims={claims} onChange={() => loadClaims(selected)}/>}
    </main></div>
  </div>;
}
