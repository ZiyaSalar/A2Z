# Claims Document Assistant — React UI (local MVP)

This is a drop-in **React/Vite frontend**, not a replacement for the existing backend, MCP server, Streamlit prototype, or terminal scripts.

## Files to add

Copy the `frontend/react/` directory into the root of `claims-document-assistant`.

No change to the existing Python code is required if your current FastAPI has these routes registered:

- `GET /api/claims/`
- `POST /api/claims/`
- `GET /api/claims/{id}/documents`
- `GET /api/claims/{id}/verification`
- `POST /api/claims/{id}/documents`
- `POST /api/chat/message`
- `POST /api/chat/confirm`
- `POST /api/chat/upload?session_id=...`
- `POST /api/chat/cancel-upload`

## Run in GitHub Codespaces

Terminal A (from repo root, Python .venv activated):

    python -m uvicorn backend.app.main:app --reload --port 8000

Terminal B:

    cd frontend/react
    npm install
    npm run dev

Open port **5173** in the Codespaces Ports tab. Keep the Ports for **5173** and **8000** private. Vite proxies `/api` requests to the local backend on port 8000, so no CORS changes are required in the recommended setup.

## Test

1. Workspace tab: select a claim and check its document list and missing-document checklist.
2. Create a fictional claim with the manual form.
3. Upload a fictional TXT/PDF/PNG/JPG to the selected claim. Check both indexes are synchronized.
4. AI assistant tab: `Create a hospitalization claim for Arav Sharma, policy POL12345`, then confirm.
5. AI assistant tab: `Upload an admission advice document to this claim`, select a file and upload.
6. AI assistant tab: `Summarize this claim`, then ask a content question such as `What was the total hospital charge?`.
7. AI assistant tab: `Which required documents are still missing?` should use authoritative verification data if your `get_claim_verification` MCP tool has been registered in `agent_service.py`.

## Scope and safety

**Development only.** No frontend authentication, claim authorization, persisted session storage, or durable write confirmations are present. Use fictional data. Never make Codespaces ports public. MCP actions should enforce authorization on the server prior to production. The request payloads match the Streamlit MVP endpoints previously provided.

Backend `.env` continues to control Azure credentials, embedding models and hybrid indexing. Do not put any Azure keys into Vite `.env` or frontend source. `VITE_API_BASE_URL` is optional, and not needed behind the Vite proxy.
