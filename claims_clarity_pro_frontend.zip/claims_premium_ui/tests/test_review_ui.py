from backend.app.api.review_ui import check_demo_approval_eligibility
from backend.app.services.claim_document_status import initialize_document_status

REQUIRED = ("admission_advice", "discharge_summary", "hospital_bill", "signed_claim_form")


def claim():
    return {"claim_id":"demo", "document_status":initialize_document_status()}


def doc(kind, status="received", needs_review=False):
    return {"document_id":kind,"document_type":kind,"document_status":status,
            "classification":{"predicted_type":kind,"needs_review":needs_review}}


def test_denied_when_document_is_missing():
    result=check_demo_approval_eligibility(claim(),[doc(k) for k in REQUIRED[:-1]])
    assert result["eligible"] is False
    assert result["verification"]["missing_documents"] == ["signed_claim_form"]


def test_denied_when_uploaded_document_requires_review():
    result=check_demo_approval_eligibility(claim(),[doc(k,"needs_review",True) if k=="admission_advice" else doc(k) for k in REQUIRED])
    assert result["eligible"] is False
    assert "admission_advice" in result["verification"]["missing_documents"]


def test_eligible_only_after_all_evidence_is_accepted():
    result=check_demo_approval_eligibility(claim(),[doc(k) for k in REQUIRED])
    assert result["eligible"] is True
    assert result["verification"]["verification_status"] == "ready_for_review"


def test_denied_if_any_unreviewed_extra_document_exists():
    result=check_demo_approval_eligibility(claim(),[doc(k) for k in REQUIRED]+[doc("hospital_bill","needs_review",True)])
    assert result["eligible"] is False
