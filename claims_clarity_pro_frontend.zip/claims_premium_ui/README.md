# Clarity — multi-page Claims Document Assistant frontend

This is the **second-generation React/Vite frontend**. It replaces only `frontend/react/` from the prior MVP. It preserves your FastAPI, MCP agent, Azure services, Streamlit prototype, and existing claim/document APIs.

## What is included

- `/` — beautiful landing/dashboard with live claim statistics and recent activity
- `/claims` — searchable and filterable claims directory
- `/claims/new` — dedicated manual claim creation form
- `/claims/:claimId` — claim workspace with **Overview**, **Documents**, **AI Summary**, **Ask AI**, **Final review** tabs
- `/agent` — full-page MCP-backed chatbot with confirmation and browser upload panels
- Citation cards and original-file viewer for images, PDFs (page navigation), and TXT, plus extracted-text evidence highlighting
- Guarded, explicitly **demo-only** human approval endpoint (disabled by default)

## Installation

1. **Back up** your current `frontend/react/` directory.
2. Copy **`frontend/react/`** from this package over your existing React folder (merge/overwrite frontend source only). It uses the existing React/Vite/lucide dependencies from your previous MVP.
3. Copy `backend/app/api/review_ui.py` into your backend's `backend/app/api/` folder.
4. Register the routes in `backend/app/main.py`:

   ```python
   from backend.app.api.review_ui import router as review_ui_router
   app.include_router(review_ui_router)
   ```

   Preserve all other router imports/registrations, especially the `chat` and `rag` routers.
5. In the repo's root terminal, run:

   ```bash
   python -m uvicorn backend.app.main:app --reload --port 8000
   ```

6. In another terminal:

   ```bash
   cd frontend/react
   npm install
   npm run dev
   ```

7. In **GitHub Codespaces**, open port **5173** via the Ports tab. Keep **all ports private**. Vite proxies `/api` to FastAPI on localhost:8000.

8. Optional **demo-only** final review button: add `ENABLE_DEMO_APPROVAL=true` to the backend `.env` then restart FastAPI. By default, the endpoint returns HTTP 403. Do **not** enable this outside a local fictional-data environment.

## Already required backend endpoints

- `GET /api/claims/`, `POST /api/claims/`, `GET /api/claims/{id}`
- `GET /api/claims/{id}/documents`, `POST /api/claims/{id}/documents`, `DELETE /api/claims/{id}/documents/{documentId}`
- `GET /api/claims/{id}/verification`, `GET /api/claims/{id}/summary?llm=true`
- `POST /api/claims/{id}/ask` (hybrid RAG)
- `POST /api/chat/message`, `/api/chat/confirm`, `/api/chat/upload`, `/api/chat/cancel-upload`

## New backend endpoints

- `GET /api/claims/{id}/documents/{documentId}/file` — claim-scoped original-file preview bytes from private Blob Storage or local upload directory
- `POST /api/claims/{id}/review/approve` — **local demo only**; validates required documents and human confirmation before marking status `approved`

## Manual test plan

1. Open `/` and verify dashboard stats load.
2. Open `/claims`, search for a fictional claim, open the claim.
3. Under **Documents**, upload a fictional hospital bill and verify it is classified/indexed.
4. Open the **original PDF/PNG/TXT** using the eye icon.
5. Under **AI Summary**, click **Generate AI summary**. This calls your existing FastAPI LLM summary endpoint.
6. Under **Ask AI**, ask "What is the total hospital bill?". Open a citation card to see the original document and evidence text.
7. Under **Final review**, verify approval is blocked if any requirement remains missing or a document is marked `needs_review`. With a fully complete fictional claim, optionally enable demo approval and test the reviewer confirmation form.
8. Visit `/agent` and create a new fictional claim, approve the creation request, upload via file picker, and request a summary.
9. Run unit tests from the repository root: `python -m pytest -q -m 'not integration'` and `python -m pytest tests/test_review_ui.py -v`.

## Important limitations before production

- **No authentication or per-claim authorization** yet. The viewer endpoint is not suitable for public access until backend identity/claim permissions are added.
- **The demo approval endpoint is not real insurance adjudication**; it lacks reviewer identity verification, tamper-proof audit logs, transactions/idempotency, and business-level plan/coverage rules. The optional `reviewer_name` field is self-reported. Keep disabled outside a local capstone demo.
- For a real approval flow, implement employee login, server-side RBAC, per-claim permissions, coverage verification, an immutable audit log, concurrency control, and an explicit workflow for flagged documents.
- OCR extracted text is not a substitute for the original document. The citation viewer deliberately shows both.
- A cited RAG answer is evidence-assistance only and always requires human review.
- Chat state persists only in the backend's temporary in-memory session manager; refresh/restart may reset sessions.

## Testing status

All frontend `.jsx`/`.js` files passed a TypeScript TSX syntax parse in this sandbox. Full Vite build was **not run successfully** here because npm registry dependencies were unavailable. Run `npm install && npm run build` in Codespaces before considering the UI verified.
